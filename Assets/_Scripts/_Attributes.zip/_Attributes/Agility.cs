public class Agility : Attribute
{
    public Agility(short value) : base (value)
    {
        
    }
}