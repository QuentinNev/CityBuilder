public class Constitution : Attribute
{
    public Constitution(short value) : base (value)
    {
        
    }
}