public class Strength : Attribute
{
    public Strength(short value) : base (value)
    {
        
    }
}