public class StrengthModifier : AttributeModifier
{
    public StrengthModifier(string label, short value) : base(label, value) { }
    public override void AddModifier(Pawn pawn)
    {
        pawn.strength.AddModifier(this);
    }

    public override void RemoveModifier(Pawn pawn)
    {
        pawn.strength.RemoveModifier(this);
    }
}