[System.Serializable]
public abstract class AttributeModifier
{
    public AttributeModifier(string label, short value)
    {
        this.label = label;
        this.value = value;
    }

    public string label;
    [Sirenix.OdinInspector.HideLabel]
    [UnityEngine.HideInInspector]
    public short value;

    public abstract void AddModifier(Pawn pawn);

    public abstract void RemoveModifier(Pawn pawn);
}