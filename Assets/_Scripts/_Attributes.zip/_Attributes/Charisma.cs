public class Charisma : Attribute
{
    public Charisma(short value) : base (value)
    {
        
    }
}