public class Intelligence : Attribute
{
    public Intelligence(short value) : base (value)
    {
        
    }
}